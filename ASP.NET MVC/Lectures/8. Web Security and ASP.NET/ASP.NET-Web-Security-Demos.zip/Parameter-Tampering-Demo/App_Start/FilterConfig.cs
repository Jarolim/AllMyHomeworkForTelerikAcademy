﻿using System.Web;
using System.Web.Mvc;

namespace Parameter_Tampering_Demo
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
