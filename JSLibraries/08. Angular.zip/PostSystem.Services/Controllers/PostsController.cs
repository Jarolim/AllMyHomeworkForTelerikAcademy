﻿using PostSystem.Data;
using PostSystem.Services.Models;
using PostSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PostSystem.Services.Controllers
{
    public class PostsController : BaseApiController
    {
        [HttpGet]
        public IQueryable<PostModel> GetPosts()
        {
            var context = new PostSystemContext();
            var models = context.Posts.Select(PostModel.FromPostToPostModel);
            return models;
        }

        [HttpPost]
        public HttpResponseMessage PostPost(PostModel model)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var context = new PostSystemContext();
                using (context)
                {
                    var postEntity = new Post
                    {
                        Title = model.Title,
                        Content = model.Content
                    };
                    var categoryEnity = context.Categories.FirstOrDefault(c => c.Name == model.Category.Name);
                    if (categoryEnity != null)
                    {
                        postEntity.Category = categoryEnity;
                        categoryEnity.Posts.Add(postEntity);
                    }

                    context.Posts.Add(postEntity);
                    context.SaveChanges();
                }

                var response = this.Request.CreateResponse(HttpStatusCode.Created);
                return response;
            });

            return responseMsg;
        }
    }
}
