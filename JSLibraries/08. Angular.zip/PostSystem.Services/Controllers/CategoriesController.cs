﻿using PostSystem.Data;
using PostSystem.Models;
using PostSystem.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PostSystem.Services.Controllers
{
    public class CategoriesController : BaseApiController
    {
        [HttpGet]
        public IQueryable<CategoryDetailsModel> GetCategories()
        {
            var context = new PostSystemContext();
            var models = context.Categories.Select(CategoryDetailsModel.FromCategoryToCategoryDetailsModel);
            return models;
        }

        [HttpPost]
        public HttpResponseMessage PostPost(CategoryModel model)
        {
            var responseMsg = this.PerformOperationAndHandleExceptions(() =>
            {
                var context = new PostSystemContext();
                using (context)
                {
                    var categoryEntity = new Category
                    {
                        Name = model.Name
                    };

                    if (context.Categories.FirstOrDefault(c=> c.Name == categoryEntity.Name) == null)
                    {
                        context.Categories.Add(categoryEntity);
                        context.SaveChanges();
                    }
                }

                var response = this.Request.CreateResponse(HttpStatusCode.Created);
                return response;
            });

            return responseMsg;
        }
    }
}
