﻿using PostSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using Newtonsoft.Json;

namespace PostSystem.Services.Models
{
    public class CategoryModel
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        public static Expression<Func<Category, CategoryModel>> FromCategoryToCategoryModel
        {
            get
            {
                return c => new CategoryModel 
                {
                    Id = c.Id,
                    Name = c.Name
                };
            }
        }
    }
}