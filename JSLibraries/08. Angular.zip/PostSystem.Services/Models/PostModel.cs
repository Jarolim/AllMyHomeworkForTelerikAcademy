﻿using PostSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using Newtonsoft.Json;

namespace PostSystem.Services.Models
{
    public class PostModel
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }
        
        [JsonProperty("content")]
        public string Content { get; set; }

        [JsonProperty("category")]
        public CategoryModel Category { get; set; }

        public static Expression<Func<Post, PostModel>> FromPostToPostModel
        {
            get
            {
                return p => new PostModel
                {
                    Id = p.Id,
                    Title = p.Title,
                    Content = p.Content,
                    Category = new CategoryModel 
                    { 
                        Id = p.Category.Id,
                        Name = p.Category.Name
                    }
                };
            }
        }


    }
}