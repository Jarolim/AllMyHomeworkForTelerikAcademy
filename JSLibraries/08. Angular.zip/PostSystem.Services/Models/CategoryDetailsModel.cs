﻿using Newtonsoft.Json;
using PostSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace PostSystem.Services.Models
{
    public class CategoryDetailsModel : CategoryModel
    {

        [JsonProperty("posts")]
        public IQueryable<PostModel> Posts { get; set; }

        public static Expression<Func<Category, CategoryDetailsModel>> FromCategoryToCategoryDetailsModel
        {
            get
            {
                return c => new CategoryDetailsModel
                {
                    Id = c.Id,
                    Name = c.Name,
                    Posts = c.Posts.AsQueryable().Select(PostModel.FromPostToPostModel)
                };
            }
        }
    }
}