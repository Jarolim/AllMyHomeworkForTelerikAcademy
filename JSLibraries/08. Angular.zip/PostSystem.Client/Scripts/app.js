﻿/// <reference path="_references.js" />
angular.module("post-system", [])
    .config(["$routeProvider", function ($routeProvider) {
        $routeProvider
            .when("/", {
                templateUrl: "Scripts/partials/home-view.html",
                controller: HomeController
            })
            .when("/post", {
                templateUrl: "Scripts/partials/all-posts-view.html",
                controller: AllPostsController
            })
            .when("/category", {
                templateUrl: "Scripts/partials/all-categories-view.html",
                controller: AllCategoriesController
            })
            .when("/category/:categoryId/posts", {
                templateUrl: "Scripts/partials/posts-from-category.html",
                controller: PostsFromCategoryController
            })
            .otherwise({ redirectTo: "/"});
    }]);