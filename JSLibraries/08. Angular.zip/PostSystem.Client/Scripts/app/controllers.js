﻿/// <reference path="../_references.js" />
function HomeController($scope) {};

function AllPostsController($scope, $http) {
    $scope.newPost = {
        title: "",
        content: "",
        category: {
            name: ""
        }
    };

    $http.get("http://localhost:63913/api/categories")
        .success(function (categories) {
            $scope.posts = [];

            _.each(categories, function (c) {
                _.each(c.posts, function (p) {
                    $scope.posts.push(p);
                });
            });

            $scope.categories = categories;
            $scope.selectedCategory = $scope.categories[0];

            $scope.addPost = function () {
                var post = $scope.newPost;

                $http.post("http://localhost:63913/api/posts", post)
                    .success(function () {
                        document.location.reload();
                    });

                $scope.newPost = {
                    title: "",
                    content: "",
                    category: {
                        name: ""
                    }
                };
            }
        });
};

function AllCategoriesController($scope, $http) {
    $scope.newCategory = {
        name: ""
    };

    $http.get("http://localhost:63913/api/categories")
        .success(function (categories) {
            $scope.categories = categories;
            $scope.addCategory = function () {
                var category = $scope.newCategory;

                $http.post("http://localhost:63913/api/categories", category)
                    .success(function () {
                        document.location.reload();
                    });

                $scope.newCategory = {
                    name: ""
                };
            }
        });
}
function PostsFromCategoryController($scope, $http, $routeParams) {
    var id = $routeParams.categoryId;
    $http.get("http://localhost:63913/api/posts")
        .success(function (posts) {
            $scope.posts = _.filter(posts, function (p) {
                return p.category.id == id;
            });
        });
};
