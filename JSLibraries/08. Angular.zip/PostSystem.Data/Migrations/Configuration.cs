namespace PostSystem.Data.Migrations
{
    using PostSystem.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    public sealed class Configuration : DbMigrationsConfiguration<PostSystem.Data.PostSystemContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(PostSystem.Data.PostSystemContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            var categories = new Category[] 
            { 
                new Category { Name = "random"}
            };

            var posts = new Post[]
            {
                new Post { Title = "Some Title", Content = "Initial Post", Category = categories[0] },
                new Post { Title = "Again a Title",  Content = "Yet another Post", Category = categories[0] }
            };

            categories[0].Posts = posts;

            context.Categories.AddOrUpdate(
               c => c.Name,
               categories[0]
               );

            context.Posts.AddOrUpdate(
                p=> p.Content,
                posts[0],
                posts[1]
                );
           
        }
    }
}
