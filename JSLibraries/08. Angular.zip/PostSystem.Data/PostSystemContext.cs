﻿using PostSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PostSystem.Data
{
    public class PostSystemContext : DbContext
    {
        public DbSet<Post> Posts { get; set; }

        public DbSet<Category> Categories { get; set; }

        public PostSystemContext()
            : base("DbPostSystem")
        { 
        }
    }
}